package com.example.day7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView a = findViewById(R.id.textView8);
        TextView b = findViewById(R.id.textView4);
        TextView c = findViewById(R.id.textView5);
        TextView d = findViewById(R.id.textView6);
        TextView e = findViewById(R.id.textView7);

       Bundle fir1 = getIntent().getExtras();
       String water1 = fir1.getString("info1");
       a.setText(water1);
       Bundle fir2 = getIntent().getExtras();
       String water2 = fir2.getString("info2");
       b.setText(water2);
       Bundle fir3 = getIntent().getExtras();
       String water3 = fir3.getString("info3");
       c.setText(water3);
       Bundle fir4 = getIntent().getExtras();
       String water4 = fir4.getString("info4");
       d.setText(water4);
       Bundle fir5 = getIntent().getExtras();
       String water5 = fir5.getString("info5");
       e.setText(water5);



    }
}