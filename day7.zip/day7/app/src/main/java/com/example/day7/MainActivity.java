package com.example.day7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button a = findViewById(R.id.button);
        final EditText b = findViewById(R.id.editTextTextPersonName);
        final EditText c = findViewById(R.id.editTextTextPersonName2);
        final EditText d = findViewById(R.id.editTextTextPersonName3);
        final EditText e = findViewById(R.id.editTextTextPersonName4);
        final EditText f = findViewById(R.id.editTextTextPersonName5);

        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent x = new Intent(MainActivity.this , MainActivity2.class);
                x.putExtra("info1",b.getText().toString());

                x.putExtra("info2",c.getText().toString());

                x.putExtra("info3",d.getText().toString());

                x.putExtra("info4",e.getText().toString());

                x.putExtra("info5",f.getText().toString());
                
                startActivity(x);
            }
        });

    }
}